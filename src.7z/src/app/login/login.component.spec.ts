import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { AuthService } from '../auth.service';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authService: AuthService;
  let btnDebugElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        ReactiveFormsModule,
        FormsModule,
      ],
      declarations: [LoginComponent],
      providers: [AuthService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent); // fixture is a wrapper for template and component
    component = fixture.componentInstance;
    authService = TestBed.get(AuthService);
    btnDebugElement = fixture.debugElement.query(By.css('button[type=submit]'));
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('AuthService is injected', () => {
    expect(authService).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.userForm.valid).toBeFalsy();
  });
  it('Username Invalid', () => {
    let username = component.userForm.controls['username'];
    expect(username.valid).toBeFalsy();
    expect(username.pristine).toBeTruthy();
    expect(username.errors['required']).toBeTruthy();
    username.setValue('abc');
    expect(username.errors['email']).toBeTruthy();
  });
  it('Username value entered is valid', () => {
    let username = component.userForm.controls['username'];
    username.setValue('abc@test.com');
    expect(username.errors).toBeNull();
  });

  it('checking password errors', () => {
    let pwd = component.userForm.controls['password'];
    expect(pwd.errors['required']).toBeTruthy();
    pwd.setValue('11234');
    expect(pwd.errors['minlength']).toBeTruthy();
  });

  it('password entered is valid', () => {
    let pwd = component.userForm.controls['password'];
    pwd.setValue('12345678');
    expect(pwd.errors).toBeNull();
    expect(pwd.valid).toBeTruthy();
  });

  it('Should check form valid or not when values entered', () => {
    component.userForm.controls['username'].setValue('test@test.com');
    component.userForm.controls['password'].setValue('12345678');
    expect(component.userForm.valid).toBeTruthy();
  });

  it('Should check form is submitted', () => {
    expect(component.userForm.invalid).toBeTruthy();
    expect(btnDebugElement.nativeElement.disabled).toBeTruthy();
    component.userForm.controls['username'].setValue('test@test.com');
    component.userForm.controls['password'].setValue('12345678');
    fixture.detectChanges();
    expect(btnDebugElement.nativeElement.disabled).toBeFalsy();
    component.loginProcess();
    fixture.detectChanges();
    // spyOn(authService,'gettoken').and.returnValue(true);
    // // expect(component.loginProcess()).toBeTruthy()
    // expect(authService.gettoken).toHaveBeenCalled();
    // expect(component.submitProduct()).toEqual(alert('Product added successfully'))
  });
});
