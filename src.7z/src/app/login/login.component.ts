import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  userForm: FormGroup;
  user='1';
  
  constructor(
    private _authService: AuthService,
    private router: Router
    
  ) {}
  ngOnInit(): void {
    this.userForm = new FormGroup({
      username: new FormControl('', [
        Validators.required,
        // Validators.pattern('^[A-Za-z_.]{6,}@[A-Za-z]{4,}[.]{1}[A-Za-z.]{2,}$')
        Validators.email,
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(8),
      ]),
    });
  }
  loginProcess() {
    // console.log(this.userForm.value);
    if (this.userForm.valid) {
      this._authService.login(this.userForm.value).subscribe((res) => {
        if (res.token == 'QpwL5tke4Pnpja7X4') {
          console.log(res);

          alert( 'Login successful');

          localStorage.setItem('SeesionUser',this.user);
          this.router.navigate(['/dashboard']);

          //
        } else {
          alert(res.token + 'Login unsuccessful');
          this.cancel();
        }
      });
    }
  }

  cancel() {
    this.userForm.reset();
  }
}
