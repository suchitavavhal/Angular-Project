import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { IntProduct } from '../int-product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-products',
  templateUrl: './list-products.component.html',
  styleUrls: ['./list-products.component.css'],
  providers: [ProductService],
})
export class ListProductsComponent implements OnInit {
  p: number = 1;
  count: number = 4;
  error: any;
  productId: number;
  products: any;
  
  

  constructor(private _productService: ProductService, private router: Router) {
    
  }

  ngOnInit(): void {
    this.getAllProducts();
  }

  getAllProducts() {
    this._productService.getProducts().subscribe((obj) => {
      this.products = obj;
      console.log(obj);
    }, 
    (error) => {
      console.log(error);
      this.error = error.message;
    });
  }

  clickDiv(product: number) {
    console.log(product);
    this.productId = product;
    this.router.navigate(['./', product]);
  }
}
