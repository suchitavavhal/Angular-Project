import { ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {HttpClientModule} from '@angular/common/http';
import { ListProductsComponent } from './list-products.component';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxPaginationModule } from 'ngx-pagination';
import { DebugElement } from '@angular/core';
import {By} from '@angular/platform-browser';
import { ProductService } from '../product.service';

class MockProductService extends ProductService{
  isAuthenticated(){
    return 'Mocked';
  }
}
describe('ListProductsComponent', () => {
  let component: ListProductsComponent;
  let fixture: ComponentFixture<ListProductsComponent>;
  let testBedService: ProductService;
  let componentService: ProductService;
  let debugElement:DebugElement;
  let htmlElement:HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,HttpClientModule,RouterTestingModule,NgxPaginationModule],
      declarations: [ ListProductsComponent ],
      providers: [ProductService]
    })
    .compileComponents();

    TestBed.overrideComponent(ListProductsComponent,{
      set: {providers: [{provide: MockProductService, useClass: MockProductService}]}
    })
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListProductsComponent);
    component = fixture.componentInstance;
   testBedService= TestBed.get(ProductService);
   componentService= fixture.debugElement.injector.get(MockProductService)
    fixture.detectChanges();
    // debugElement= fixture.debugElement.query(By.css('#cardProd'));
    // htmlElement= debugElement.nativeElement;
  });

  it('should create Component', () => {
    expect(component).toBeTruthy();
  });

  it('should contain method to get all products', () => {
    expect(component.getAllProducts).toBeTruthy();
  });

 it('Service injected via inject & TestBed.get should get same instance',()=>{
  inject([ProductService],(injectService:ProductService)=>{
    expect(injectService).toBe(testBedService);
  })
 })

it('Service injected via component should be and instance of MockAuthService ', ()=>{
  expect(componentService instanceof MockProductService).toBeTruthy();
})
});
