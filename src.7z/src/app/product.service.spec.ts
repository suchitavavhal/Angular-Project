import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { ProductService } from './product.service';
import { IntProduct } from './int-product';


describe('ProductService', () => {
  let service: ProductService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ProductService],
    });
    service = TestBed.get(ProductService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Method retrieves all products', () => {
    let products:IntProduct[];
    const num: number = 0;
    service.getProducts().subscribe((data) => (products = data));
    // expect(products[num].title).toBe(
    //   'Fjallraven - Foldsack No. 1 Backpack, Fits 15 Laptops'
    // );
    expect(products).toBeTruthy();
  });
});
