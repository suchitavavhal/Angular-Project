import { UserService } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  id: number;
  user: any;
  constructor(
    private _userService: UserService,
    private _route: ActivatedRoute,
    private _location: Location
  ) {}

  ngOnInit(): void {
    this.id = this._route.snapshot.params['id'];
    this._userService.find(this.id).subscribe((data: any) => {
      this.user = data.data;
      console.log(data);
    });
  }
  back() {
    this._location.back();
  }

}
