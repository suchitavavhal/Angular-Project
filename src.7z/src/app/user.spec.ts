import { User } from './user';

describe('User', () => {
  let obj = {} as User;

  it('should create an instance', () => {
    expect(obj).toBeTruthy();
  });
});
