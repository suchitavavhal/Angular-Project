import { Component, OnInit,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
@Output() open: EventEmitter<any> = new EventEmitter();

loaded=false;
  constructor() { }

  ngOnInit(): void {
    this.open.emit(this.loaded);

  }
}
