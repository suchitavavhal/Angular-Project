import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  users: any[] = [];
  p: number = 1;

  constructor(public _userService: UserService) {}

  ngOnInit(): void {
    this._userService.getAll().subscribe((data: any[]) => {
      this.users = data;
      console.log(this.users);
    });
  }

  geoLocation: object;

  displayStyle = 'none';

  openMap(data: object) {
    this.geoLocation = data;
    console.log(data);

    this.displayStyle = 'block';
  }
  closeMap() {
    this.displayStyle = 'none';
  }


}
