import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { IntProduct } from '../int-product';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-product-desc',
  templateUrl: './product-description.component.html',
  styleUrls: ['./product-description.component.css'],
  providers: [ProductService],
})
export class ProductDescriptionComponent implements OnInit {
  top = '15';
  right = '92';
  lensWidth = '100';
  lensHeight = '100';
  resultWidth = '35';
  resultHeight = '70';
  imgWidth = '200';
  imgHeight = '200';
  
  product: IntProduct;
  id: any;
  // products: any;
  prodId: any;
  rating: any;
  rate: any;
  sub: any;
  error:any;
  myproduct: IntProduct;
  roundRate: any = [];

  constructor(
    private _productService: ProductService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this._productService
      .getProductById(this.id)
      .subscribe((obj: IntProduct) => {
        this.product = obj;
        console.log('product' + this.product);
        this.rating = this.product.rating;
        this.rate = this.rating.rate;
        this.roundRate = Math.round(this.rate);
      },(error) => {
        console.log(error);
        this.error = error.message;
      } );
  }

  // getProduct() {
  //   this._productService.getProductById(this.prodId).subscribe((obj) => {
  //     this.product = obj;
  //   }, (error) => {
  //     console.log(error);
  //     this.error = error.message;
  //   });
  // }

  onBack(): void {
    this.router.navigate(['./dashboard/listproducts']);
  }
}
