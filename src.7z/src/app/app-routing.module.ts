import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component'; //
import { DashboardComponent } from './dashboard/dashboard.component'; //
import {ListProductsComponent} from './list-products/list-products.component'; //
import {LoginComponent} from './login/login.component'; //
import { WelcomeComponent } from './welcome/welcome.component'; //
import {UserComponent} from './user/user.component'; //
import { AuthGuardGuard } from './auth-guard.guard';
import {UserDetailsComponent} from './user-details/user-details.component'; //
import {ProductDescriptionComponent} from './product-description/product-description.component'; //
import{AddUserComponent} from './add-user/add-user.component';
import {AddProductComponent} from './add-product/add-product.component';


const routes: Routes = [
 
  {path:"", redirectTo:"/login", pathMatch:'full'},
  {path:'login', component: LoginComponent , pathMatch: 'full'},
{path:"dashboard", component:DashboardComponent,
canActivate: [AuthGuardGuard],
children: [
  {path:"", component:WelcomeComponent},
  {path:"welcome", component:WelcomeComponent},
  {path:'listproducts', component:ListProductsComponent},
  {path: 'listproducts/:id', component: ProductDescriptionComponent },
  {path: 'add-product', component: AddProductComponent },
  {path: 'user-list',component: UserComponent },
  {path: 'user-list/details/:id', component: UserDetailsComponent },
  {path: 'add-user', component: AddUserComponent },
  {path: "pgnf", component:PageNotFoundComponent},
  {path: "**",component:PageNotFoundComponent, pathMatch:'full'}
]
},
{path: "pgnf", component:PageNotFoundComponent},
  {path: "**",redirectTo: '/pgnf', pathMatch:'full'}]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {   }
export const routingComponents=[ProductDescriptionComponent,WelcomeComponent,
  PageNotFoundComponent, DashboardComponent, ListProductsComponent,LoginComponent,UserComponent, UserDetailsComponent, AddUserComponent,AddProductComponent]