import {AddProductComponent} from './add-product.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {RouterTestingModule} from '@angular/router/testing'
import { TestBed, ComponentFixture} from '@angular/core/testing';
import {ProductService} from '../product.service';

import {
  ReactiveFormsModule, FormsModule, EmailValidator
} from '@angular/forms';



describe('AddProductComponent', ()=>{
  let component: AddProductComponent;
  let fixture: ComponentFixture<AddProductComponent>;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule,HttpClientTestingModule, RouterTestingModule],
      declarations: [AddProductComponent],
      providers: [ProductService]
    }).compileComponents();
  });
  beforeEach(() => {
    fixture = TestBed.createComponent(AddProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.ngOnInit();
    
  });

  it('form invalid when empty', () => {
    expect(component.addProductForm.valid).toBeFalsy();
  });

  it('Empty ProductName tobe invalid',()=>{
    let productNm= component.addProductForm.controls['productName'];
    expect(productNm.valid).toBeFalsy()

    let errors={};
    errors= productNm.errors || {};
    expect(errors['required']).toBeTruthy();
   })

   it('Empty Price tobe invalid',()=>{
    let price= component.addProductForm.controls['price'];
    expect(price.errors['required']).toBeTruthy();
    price.setValue('as');
    expect(price.errors['pattern']).toBeTruthy();
    
   })
   it('Empty Product Description tobe invalid',()=>{
    let prodDesc= component.addProductForm.controls['desc'];
    expect(prodDesc.valid).toBeFalsy()

    let errors={};
    errors= prodDesc.errors || {};
    expect(errors['required']).toBeTruthy();
   })
   it('Empty Product Category tobe invalid',()=>{
    let productCat= component.addProductForm.controls['category'];
    expect(productCat.valid).toBeFalsy()

    let errors={};
    errors= productCat.errors || {};
    expect(errors['required']).toBeTruthy();
   })

  xit('component should be created',()=>{
    expect(component).toBeTruthy()
  })

  it('submit method has an alert', ()=>{
    expect(component.submitProduct()).toEqual(alert('Product added successfully'))
  })

})