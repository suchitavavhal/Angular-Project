import { Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css'],
})
export class AddProductComponent implements OnInit {
  addProductForm: FormGroup;
  error: any;
  constructor(private productService: ProductService, private router: Router) {}

  ngOnInit(): void {
    this.addProductForm = new FormGroup({
      productName: new FormControl('', [Validators.required]),
      price: new FormControl('', [
        Validators.required,
        Validators.pattern('^[0-9]{2,}$'),
      ]),
      desc: new FormControl('', [Validators.required]),
      category: new FormControl('', [Validators.required]),
    });
  }

  submitProduct() {
    console.log(this.addProductForm.value);
    if (this.addProductForm.valid) {
      alert('Product added successfully');
      let text = 'Do you want to add another product?';
      if (confirm(text) == true) {
        this.cancel();
      } else {
        this.router.navigate(['/dashboard']);
       
      }
    }
  }

  cancel() {
    this.addProductForm.reset();
  }
}
