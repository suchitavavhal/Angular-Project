import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  userForm: FormGroup;

  passwordCheck = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;
  emailCheck = /^[A-Za-z0-9_.]{6,}@[A-Za-z]{4,}[.]{1}[A-Za-z.]{2,}$/;

  constructor(private _fb: FormBuilder, private _userService: UserService) {}

  ngOnInit(): void {
    this.userForm = this._fb.group({
      username: new FormControl('', [
        Validators.required,
        Validators.pattern(this.emailCheck),
      ]),
      password: new FormControl('', [
        Validators.required,
        // Validators.pattern(this.passwordCheck),
      ]),
    });
  }
  get check() {
    return this.userForm.controls;
  }

  submitForm() {
    this._userService.create(this.userForm.value).subscribe((res: any) => {
      alert('User Added successfully!');
    });
    console.log(this.userForm.value);
    this.userForm.reset();
  }
  cancel() {
    this.userForm.reset();
  }
}
