import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {IntProduct} from './int-product';
import {Observable} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  apiurl='https://fakestoreapi.com/products';
 
  
    constructor(private _httpClient: HttpClient) { }
  
    getProducts():Observable<IntProduct[]>{
      return this._httpClient.get<IntProduct[]>(this.apiurl);
    }

    getProductById(productId:number):Observable<IntProduct>{
      return this._httpClient.get<IntProduct>(this.apiurl  + "/" +productId);
    }
   
    
    
}
