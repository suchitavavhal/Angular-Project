export interface User {
  id: number;
  name: string;
  username: string;
  city: string;
  zipcode: string;
  location: string;
}
