import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from './user';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private apiURL = 'https://jsonplaceholder.typicode.com';

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  constructor(private _httpClient: HttpClient) {}

  getAll(): Observable<User[]> {
    return this._httpClient
      .get<any[]>(this.apiURL + '/users/')
      .pipe(catchError(this.errorHandler));
  }

  create(user: any): Observable<User> {
    return this._httpClient
      .post<any>(
        'https://reqres.in/api/register',
        JSON.stringify(user),
        this.httpOptions
      )
      .pipe(catchError(this.errorHandler));
  }

  find(id: number): Observable<User> {
    return this._httpClient
      .get<any>('https://reqres.in/api/users/' + id)
      .pipe(catchError(this.errorHandler));
  }

  // update(id:number, user:any): Observable<User> {
  //   return this._httpClient
  //     .put<User>(
  //       this.apiURL + '/posts/' + id,
  //       JSON.stringify(post),
  //       this.httpOptions
  //     )
  //     .pipe(catchError(this.errorHandler));
  // }

  // delete(id:number) {
  //   return this._httpClient
  //     .delete<User>(this.apiURL + '/posts/' + id, this.httpOptions)
  //     .pipe(catchError(this.errorHandler));
  // }

  errorHandler(error: any) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
