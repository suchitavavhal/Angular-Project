import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mathRound'
})
export class MathRoundPipe implements PipeTransform {

  transform(val: number): unknown {
    if(!val){
      return null;
    }
    return Math.round(val);
  }

}
