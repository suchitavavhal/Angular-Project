import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { Observable, Subject, throwError } from 'rxjs';
import { User } from './user';
import { catchError, tap } from 'rxjs/operators';
import { Router } from '@angular/router';

export interface AuthResponseData {
  kind: string;
  idToken: string;
  email: string;
  refreshToken: string;
  expiresIn: string;
  localId: string;
  registered?: boolean;
}
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user = new Subject<User>();

  url = 'https://reqres.in/api/login';
  constructor(private http: HttpClient, private router: Router) {}

  login(data): Observable<any> {
    return this.http.post<AuthResponseData>(this.url, data).pipe(
      catchError(this.handleError),
      tap((response) => {
        this.handleAuthentication(response.token);
      })
    );
  }

  handleAuthentication(token: any) {
    localStorage.setItem('accessToken', JSON.stringify(token));
  }

  public handleError(errRes: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (!errRes.error || !errRes.error.error) {
      return throwError(errorMessage);
    }
    return throwError(errorMessage);
  }

  gettoken() {
    return !!localStorage.getItem('SeesionUser');
  }
  logout() {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('SeesionUser');
    this.router.navigate(['/login']);
  }
}
