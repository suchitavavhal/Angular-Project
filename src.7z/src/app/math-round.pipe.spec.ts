import { MathRoundPipe } from './math-round.pipe';

describe('MathRoundPipe', () => {
let pipe: MathRoundPipe;

  beforeEach(()=>{
    pipe = new MathRoundPipe();
  })
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });
  it('rounds up the value', () => {
    let value=2.3;
    expect(pipe.transform(value)).toEqual(Math.round(value));
  });

  it('returns null for null argument', () => {
    let value=null;
    expect(pipe.transform(value)).toBe(null);
  });
});
