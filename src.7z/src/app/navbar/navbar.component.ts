import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import {  } from '../product.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private _authService:AuthService) { }

  ngOnInit(): void {
    
  }
  opened= true;
  prodDisp=false;
  display=false;
  chngColorProd='';
  chngColorUser="";

  changeDisplay(input:any){
    if(input=='product'){
    this.prodDisp=!this.prodDisp;
    this.display=false;
    this.chngColorProd='rgb(198, 198, 233)';
    this.chngColorUser= 'transparent';
    
  }

    if(input=='user')
    {
      this.display= !this.display;
      this.prodDisp= false;
      this.chngColorProd='transparent';
      this.chngColorUser= 'rgb(198, 198, 233)';
    }

  }

  signout(){
    this._authService.logout()
  }


}
